chrome.runtime.onInstalled.addListener(() => {
  console.log('WhatsBlitz Extension installed');
});
console.log("WhatsBlitz background service worker running");
